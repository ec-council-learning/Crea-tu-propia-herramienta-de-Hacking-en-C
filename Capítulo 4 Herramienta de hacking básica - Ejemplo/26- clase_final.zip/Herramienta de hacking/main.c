#include<stdio.h>
#include<stdlib.h>
#include "functions.h"

int main(){
	system("color a");
	system("title toolZ");
	system("mkdir logs");
	mainProg();
	cleanc();
	return 0;
}
